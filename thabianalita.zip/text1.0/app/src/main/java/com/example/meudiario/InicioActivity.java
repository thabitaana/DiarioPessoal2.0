package com.example.meudiario;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {

    private static final int TEMPO_ESPERA = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activit_tela_inicio);

        new Handler().postDelayed(() -> {
            SharedPreferences prefs = getSharedPreferences("configuracoes", MODE_PRIVATE);
            boolean jaCadastrado = prefs.getBoolean("cadastro_realizado", false);

            Intent intent;
            if (jaCadastrado) {

                intent = new Intent(InicioActivity.this, SenhaActivity.class);
            } else {

                intent = new Intent(InicioActivity.this, CadastroActivity.class);
            }
            startActivity(intent);
            finish();
        }, TEMPO_ESPERA);
    }
    }