package com.example.meudiario;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class BancoHelper extends SQLiteOpenHelper {

    private static final String NOME_BANCO = "diario.db";
    private static final int VERSAO = 1;

    public BancoHelper(Context contexto) {
        super(contexto, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE anotacoes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "titulo TEXT," +
                "texto TEXT," +
                "data TEXT," +
                "emocao TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int vAntiga, int vNova) {
        db.execSQL("DROP TABLE IF EXISTS anotacoes");
        onCreate(db);
    }

    public long salvar(String titulo, String texto, Date data, String emocao) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valores = new ContentValues();
        valores.put("titulo", titulo);
        valores.put("texto", texto);
        valores.put("data", formatarData(data));
        valores.put("emocao", emocao);
        long id = db.insert("anotacoes", null, valores);
        db.close();
        return id;
    }

    public ArrayList<AnotacaoActivit> buscarPorData(Date data) {
        ArrayList<AnotacaoActivit> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String dataStr = formatarData(data);
        Cursor cursor = db.rawQuery("SELECT * FROM anotacoes WHERE data = ?", new String[]{dataStr});

        while (cursor.moveToNext()) {
            AnotacaoActivit a = new AnotacaoActivit();
            a.setId(cursor.getInt(0));
            a.setTitulo(cursor.getString(1));
            a.setTexto(cursor.getString(2));
            a.setData(cursor.getString(3));
            a.setEmocao(cursor.getString(4));
            lista.add(a);
        }
        cursor.close();
        db.close();
        return lista;
    }

    private String formatarData(Date data) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(data);
    }

    public ArrayList<AnotacaoActivit> pesquisar(String palavra) {
        ArrayList<AnotacaoActivit> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String termo = "%" + palavra + "%";

        Cursor cursor = db.rawQuery(
                "SELECT * FROM anotacoes WHERE titulo LIKE ? OR texto LIKE ? ORDER BY data DESC",
                new String[]{termo, termo}
        );

        while (cursor.moveToNext()) {
            AnotacaoActivit a = new AnotacaoActivit();
            a.setId(cursor.getInt(0));
            a.setTitulo(cursor.getString(1));
            a.setTexto(cursor.getString(2));
            a.setData(cursor.getString(3));
            a.setEmocao(cursor.getString(4));
            lista.add(a);
        }
        cursor.close();
        db.close();
        return lista;
    }
}
