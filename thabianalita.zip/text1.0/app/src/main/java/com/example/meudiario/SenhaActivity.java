package com.example.meudiario;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SenhaActivity extends AppCompatActivity {

    private EditText campoSenha;
    private Button btnEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senha);

        campoSenha = findViewById(R.id.campoSenha);
        btnEntrar = findViewById(R.id.btnEntrar);

        btnEntrar.setOnClickListener(v -> verificarSenha());
    }

    private void verificarSenha() {
        String senhaDigitada = campoSenha.getText().toString().trim();


        if (senhaDigitada.isEmpty()) {
            Toast.makeText(this, "Digite sua senha!", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Bem-vindo!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(SenhaActivity.this, CalendarioActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}