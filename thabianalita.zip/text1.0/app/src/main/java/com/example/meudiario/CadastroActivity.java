package com.example.meudiario;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText campoUsuario, campoSenha, campoConfirmarSenha;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro_main);

        campoUsuario = findViewById(R.id.campoUsuario);
        campoSenha = findViewById(R.id.campoSenha);
        campoConfirmarSenha = findViewById(R.id.campoConfirmarSenha);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(v -> validarDados());
    }

    private void validarDados() {
        String usuario = campoUsuario.getText().toString().trim();
        String senha = campoSenha.getText().toString().trim();
        String confirmarSenha = campoConfirmarSenha.getText().toString().trim();

        if (usuario.isEmpty()) {
            Toast.makeText(this, "Digite seu usuário!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (senha.isEmpty()) {
            Toast.makeText(this, "Digite sua senha!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (confirmarSenha.isEmpty()) {
            Toast.makeText(this, "Confirme sua senha!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!senha.equals(confirmarSenha)) {
            Toast.makeText(this, "As senhas não coincidem!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (senha.length() < 4) {
            Toast.makeText(this, "A senha precisa ter pelo menos 4 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Cadastro realizado!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(CadastroActivity.this, SenhaActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Limpa a pilha
        startActivity(intent);
        finish();
    }
}