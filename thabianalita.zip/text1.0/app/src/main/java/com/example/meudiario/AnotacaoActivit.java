package com.example.meudiario;

public class AnotacaoActivit {

    private int id;
    private String titulo;
    private String texto;
    private String data;
    private String emocao;

    public AnotacaoActivit() {
    }

    public AnotacaoActivit(int id, String titulo, String texto, String data, String emocao) {
        this.id = id;
        this.titulo = titulo;
        this.texto = texto;
        this.data = data;
        this.emocao = emocao;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }


    public String getEmocao() {
        return emocao;
    }

    public void setEmocao(String emocao) {
        this.emocao = emocao;
    }
}