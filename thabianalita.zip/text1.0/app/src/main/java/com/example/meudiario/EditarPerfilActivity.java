package com.example.meudiario;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditarPerfilActivity extends AppCompatActivity {

    private EditText campoNome, campoEmail;
    private Button btnSalvar, btnVoltar;

    private SharedPreferences preferencias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_perfil);

        campoNome = findViewById(R.id.campoNome);
        campoEmail = findViewById(R.id.campoEmail);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnVoltar = findViewById(R.id.btnVoltar);

        preferencias = getSharedPreferences(
                "PerfilUsuario", MODE_PRIVATE
        );

        campoNome.setText(
                preferencias.getString("nome", "")
        );

        campoEmail.setText(
                preferencias.getString("email", "")
        );

        btnSalvar.setOnClickListener(v -> salvarPerfil());

        btnVoltar.setOnClickListener(v -> finish());
    }

    private void salvarPerfil() {
        String nome = campoNome.getText().toString().trim();
        String email = campoEmail.getText().toString().trim();

        if (nome.isEmpty() || email.isEmpty()) {
            Toast.makeText(
                    this,
                    "Preencha todos os campos.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        preferencias.edit()
                .putString("nome", nome)
                .putString("email", email)
                .apply();

        Toast.makeText(
                this,
                "Perfil salvo com sucesso!",
                Toast.LENGTH_SHORT
        ).show();

        finish();
    }
}
