package com.example.meudiario;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PerfilActivity extends AppCompatActivity {

    private TextView textoUsuario, textoSaudacao;
    private Button btnEditarPerfil, btnTrocarSenha, btnSobre, btnSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        textoUsuario = findViewById(R.id.textoUsuario);
        textoSaudacao = findViewById(R.id.textoSaudacao);

        btnEditarPerfil = findViewById(R.id.btnEditarPerfil);
        btnTrocarSenha = findViewById(R.id.btnTrocarSenha);
        btnSobre = findViewById(R.id.btnSobre);
        btnSair = findViewById(R.id.btnSair);

        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());

        btnEditarPerfil.setOnClickListener(v -> {
            Intent intent = new Intent(
                    PerfilActivity.this,
                    EditarPerfilActivity.class
            );
            startActivity(intent);
        });

        btnTrocarSenha.setOnClickListener(v -> {
            Intent intent = new Intent(PerfilActivity.this, SenhaActivity.class);
            startActivity(intent);
        });

        btnSair.setOnClickListener(v -> finishAffinity());
    }
}
