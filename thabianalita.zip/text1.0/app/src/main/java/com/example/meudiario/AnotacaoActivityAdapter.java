package com.example.meudiario;

public class AnotacaoActivityAdapter {
}
