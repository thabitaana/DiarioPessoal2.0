package com.example.meudiario;

public class EditarAnotacaoActivity {
}
