package com.example.meudiario;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CalendarioActivit extends AppCompatActivity {

    private CalendarView calendario;
    private TextView textoDataEscolhida, textoSemAnotacoes;
    private ListView listaAnotacoes;
    private Button btnNovo;
    private Date dataSelecionada;
    private BancoHelper banco;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activit_calendario);

        banco = new BancoHelper(this);

        calendario = findViewById(R.id.calendario);
        textoDataEscolhida = findViewById(R.id.textoDataEscolhida);
        textoSemAnotacoes = findViewById(R.id.textoSemAnotacoes);
        listaAnotacoes = findViewById(R.id.listaAnotacoes);
        btnNovo = findViewById(R.id.btnNovo);

        dataSelecionada = new Date();

        atualizarTextoData();
        carregarAnotacoesDoDia();

        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());

        calendario.setOnDateChangeListener((view, ano, mes, dia) -> {
            Calendar cal = Calendar.getInstance();
            cal.set(ano, mes, dia, 12, 0, 0);
            cal.set(Calendar.MILLISECOND, 0);

            dataSelecionada = cal.getTime();

            atualizarTextoData();
            carregarAnotacoesDoDia();
        });

        btnNovo.setOnClickListener(v -> {
            Intent intent = new Intent(
                    CalendarioActivit.this,
                    EditarAnotacaoActivity.class

            );

            intent.putExtra("data", dataSelecionada.getTime());
            startActivity(intent);
        });

        listaAnotacoes.setOnItemClickListener(
                (parent, view, posicao, id) -> {
                    AnotacaoActivit anotacao =
                            (AnotacaoActivit) parent.getItemAtPosition(posicao);

                    Intent intent = new Intent(
                            CalendarioActivit.this,
                            EditarAnotacaoActivity.class
                    );

                    intent.putExtra("id", anotacao.getId());
                    startActivity(intent);
                }
        );
    }

    private void atualizarTextoData() {
        SimpleDateFormat formato =
                new SimpleDateFormat("EEEE, dd/MM/yyyy", new Locale("pt", "BR"));

        textoDataEscolhida.setText(formato.format(dataSelecionada));
    }

    private void carregarAnotacoesDoDia() {
        ArrayList<AnotacaoActivit> lista =
                banco.buscarPorData(dataSelecionada);

        if (lista.isEmpty()) {
            textoSemAnotacoes.setVisibility(View.VISIBLE);
            listaAnotacoes.setVisibility(View.GONE);
        } else {
            textoSemAnotacoes.setVisibility(View.GONE);
            listaAnotacoes.setVisibility(View.VISIBLE);
            AnotacaoActivityAdapter adaptador = new AnotacaoActivit (this, lista);
            listaAnotacoes.setAdapter(adaptador);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (banco != null) {
            carregarAnotacoesDoDia();
        }
    }
}